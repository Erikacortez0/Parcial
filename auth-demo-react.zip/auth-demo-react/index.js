import  express from "express";
import cors from "cors"
import UserRoute from "./routes/Userroute.js";
//we'll create our server
const app = express()
//became json response
app.use(express.json())
//hability the cars
app.use(cors())

//difine a port
const PORT =process.env.port ?? 2000
app.use(UserRoute)

//running the serve

app.listen(PORT,()=>{
    console.log(`Server runningat the port ${PORT}`);
})